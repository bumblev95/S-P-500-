"""Restore only PR #56 files. Default is a dry run; refuses later file changes."""
import argparse, hashlib, json
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--apply',action='store_true')
a=p.parse_args(); repo=a.repo.resolve(); backup=Path(__file__).resolve().parent
m=json.loads((backup/'manifest.json').read_text()); actions=[]
sha=lambda b:hashlib.sha256(b).hexdigest()
for entry in m['files']:
    relative=Path(entry['path']); target=repo/relative
    if relative.is_absolute() or '..' in relative.parts:
        raise SystemExit('Unsafe backup path: '+str(relative))
    if target.is_symlink(): raise SystemExit('Refusing symlink: '+str(relative))
    before=entry['beforeSha256']; after=entry['updatedSha256']
    original=(backup/'files'/relative).read_bytes() if before else None
    if original is not None and sha(original)!=before:
        raise SystemExit('Backup checksum mismatch: '+str(relative))
    current=sha(target.read_bytes()) if target.exists() else None
    if current not in (before,after):
        raise SystemExit('File changed after this fix; review manually: '+str(relative))
    if current!=before: actions.append((entry,target,original))
print('Original main:',m['preChangeCommit'])
for entry,target,original in actions:
    print(('RESTORE ' if original is not None else 'REMOVE NEW FILE ')+entry['path'])
if not a.apply: print('Dry run only. Add --apply after reviewing the list.')
else:
    for entry,target,original in actions:
        if original is None: target.unlink()
        else:
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original)
            target.chmod(int(entry['beforeMode'],8)&0o777)
    print('Restored',len(actions),'files. Review the diff and tests before publishing.')
